# Araku-Valley-Tourism-Website
A  multi-page website for Araku Valley tourism created using HTML,CSS and Javascript.No templates have been used.

Visit:
https://himabindugssn.github.io/Araku-Valley-Tourism-Website/


 Home page:
 
 
 ![bandicam 2019-07-09 15-56-52-920](https://user-images.githubusercontent.com/47247696/60882901-6e282780-a266-11e9-862d-88768cb185ad.jpg)
 

 References:
 
  www.w3schools.com
  
  www.nativeplanet.com
  
 images from google



